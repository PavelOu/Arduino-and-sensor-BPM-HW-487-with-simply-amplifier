DataSerial/10/com
Parameters for communication with Arduinos and Esp via port Com
04.06.2026*13:47:45
Port:Com,3,9600,8,1,0
Timing:Timer=10,Sleep=10,Wait=300,Timeout=100
end
